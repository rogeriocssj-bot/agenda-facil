@echo off
cd /d "%~dp0"
del /q "database\agendafacil-local.sqlite" 2>nul
echo Dados apagados. Abra o AgendaFacil de novo para recomecar com os dados iniciais.
pause
