# Texto da narração: Vídeo 1 (solução em funcionamento, 6min33s)

**Como usar:** abra o `video1_agendafacil.mp4` no **CapCut** ou no **Clipchamp** (já vem no Windows) e use a opção **Gravar narração / Voz**. Leia cada bloco quando o vídeo chegar no tempo indicado, em ritmo tranquilo. As legendas na tela ajudam a se localizar. Exporte em MP4 e publique no YouTube como **Não listado**.

> Troque [seu nome] e [seu RGM] pelos dados do aluno.

---

**0:00 – Abertura**
Olá, meu nome é [seu nome], RGM [seu RGM]. Este é o AgendaFácil, o sistema que desenvolvi no Projeto Integrador Transdisciplinar em Engenharia de Software II. Ele foi feito em PHP 8, no padrão MVC, com banco de dados MySQL e front-end em HTML, CSS e JavaScript.

**0:23 – O problema e a página inicial**
A ideia surgiu de um problema comum: salões e barbearias marcam horários pelo WhatsApp ou num caderno, e isso gera horário duplicado e muita mensagem para responder. No AgendaFácil o próprio cliente agenda. Na página inicial ele já vê os serviços, com a duração e o preço de cada um.

**0:50 – Criar conta e validações**
Vou criar uma conta. Se eu tentar enviar com os campos vazios, o sistema mostra embaixo de cada campo o que está faltando. Essa validação é feita no navegador e repetida no servidor, por segurança. O telefone recebe máscara automática, e a senha tem o botão Mostrar para conferir o que foi digitado. Conta criada: o sistema já me leva direto para o agendamento.

**1:33 – Agendamento em 4 passos**
O agendamento tem quatro passos. Primeiro escolho o serviço, aqui a coloração, que dura duas horas. Depois o profissional: só aparece quem realmente faz esse serviço. Se eu escolher um domingo, o sistema avisa que não há atendimento. Escolhendo a segunda-feira, aparecem só os horários livres. Repare que o último horário é dezesseis horas, porque a coloração termina às dezoito, que é o fechamento. E entre onze e meia e quatorze e meia não aparece nada, porque a profissional já tem uma cliente das treze às quinze. Escolho as dez horas, coloco uma observação e confirmo. Aparece o resumo do agendamento.

**2:23 – Horário reservado sai da lista**
Se eu abrir o agendamento de novo, para a mesma profissional e o mesmo dia, o período das dez ao meio-dia sumiu. Assim não tem como marcar horário duplicado.

**2:37 – Meus agendamentos**
Em Meus agendamentos o cliente vê data, horário, serviço, profissional, valor e status. Ele pode cancelar pelo sistema até duas horas antes do horário marcado.

**2:55 – Área do administrador**
Agora vou entrar como administrador. Se a senha estiver errada, o sistema mostra uma mensagem clara, sem dizer qual dos dois campos errou, por segurança. Com a senha certa, abre o painel com os indicadores do mês: agendamentos ativos, atendimentos concluídos, cancelamentos, faturamento previsto e número de clientes. Embaixo ficam os atendimentos de hoje.

**3:37 – Agenda e status**
Na agenda geral o administrador filtra por data, profissional e status. Ele também muda o status de cada atendimento. Vou confirmar o atendimento da Luana e concluir o da Maria. Repare que o atendimento concluído não oferece mais nenhuma ação: concluído e cancelado são estados finais.

**4:10 – Serviços e profissionais**
No cadastro de serviços, se eu repetir um nome que já existe e colocar um preço inválido, o servidor recusa e mostra os dois erros. Corrigindo os dados, o serviço é cadastrado. Na tela de profissionais aparecem os serviços que cada um realiza. Essa é uma relação muitos-para-muitos no banco de dados.

**4:52 – Versão celular**
O layout é responsivo. No celular os cartões ficam em uma coluna, as tabelas viram listas e o menu fica recolhido neste botão.

**5:14 – Código MVC**
Este é o código. A pasta app está dividida em Models, que acessam o banco, Views, que montam as telas, e Controllers, que recebem as requisições. As regras de negócio ficam separadas na classe AgendamentoService: não agendar no passado, respeitar o expediente e não deixar horários se sobreporem.

**5:41 – Testes automatizados**
Por fim, os testes automatizados com PHPUnit. São cinquenta e oito testes, unitários e de integração com o banco de dados. Eles cobrem todas as regras de negócio. O resultado é OK: cinquenta e oito testes, cento e sete verificações e nenhuma falha.

**6:22 – Encerramento**
O código e toda a documentação estão no meu repositório do GitHub. Obrigado!
