#!/bin/bash
# Apaga o banco local para começar do zero (os dados iniciais voltam na próxima abertura).
cd "$(dirname "$0")" || exit 1
rm -f database/agendafacil-local.sqlite
echo "Dados apagados. Abra o AgendaFácil de novo para recomeçar com os dados iniciais."
read -r -p "Enter para fechar"
