<?php
declare(strict_types=1);

namespace Tests\Integration;

use App\Models\Agendamento;
use App\Models\Profissional;
use App\Models\Servico;
use App\Services\AgendamentoService;
use App\Services\RegraNegocioException;
use DateTimeImmutable;
use PDO;
use PHPUnit\Framework\TestCase;
use Tests\BancoDeTeste;

/**
 * Testes de integração: regras de negócio + models + banco de dados.
 * Datas fixas: 07/01/2030 é segunda-feira; 06/01/2030 é domingo.
 */
final class AgendamentoServiceTest extends TestCase
{
    private const SEGUNDA = '2030-01-07';
    private const DOMINGO = '2030-01-06';
    private const MARIA = 2;
    private const JOAO = 3;
    private const CORTE = 1;
    private const COLORACAO = 2;
    private const CARLOS = 1;
    private const ANA = 2;

    private PDO $pdo;
    private AgendamentoService $service;
    private Agendamento $agendamentos;
    private DateTimeImmutable $agora;

    protected function setUp(): void
    {
        $this->pdo = BancoDeTeste::criar();
        $this->agendamentos = new Agendamento($this->pdo);
        $this->service = new AgendamentoService(
            $this->agendamentos,
            new Servico($this->pdo),
            new Profissional($this->pdo),
            [
                'abertura' => '08:00', 'fechamento' => '18:00',
                'dias_funcionamento' => [1, 2, 3, 4, 5, 6],
                'antecedencia_cancelar_h' => 2, 'intervalo_slots_min' => 30,
            ],
        );
        $this->agora = new DateTimeImmutable('2030-01-01 10:00');
    }

    private function agendar(int $cliente = self::MARIA, int $servico = self::CORTE, int $prof = self::CARLOS,
                             string $data = self::SEGUNDA, string $hora = '09:00'): int
    {
        return $this->service->agendar($cliente, $servico, $prof, $data, $hora, null, $this->agora);
    }

    public function testAgendamentoValidoEGravadoComHoraFimCalculada(): void
    {
        $id = $this->agendar();
        $ag = $this->agendamentos->buscarCompleto($id);

        $this->assertSame('agendado', $ag['status']);
        $this->assertSame('09:00:00', $ag['hora_inicio']);
        $this->assertSame('09:30:00', $ag['hora_fim']);
        $this->assertSame('Corte', $ag['servico_nome']);
        $this->assertSame('Carlos', $ag['profissional_nome']);
    }

    public function testNaoPermiteAgendarNoPassado(): void
    {
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('já passou');
        $this->service->agendar(self::MARIA, self::CORTE, self::CARLOS, '2029-12-31', '09:00', null, $this->agora);
    }

    public function testNaoPermiteAgendarNoDomingo(): void
    {
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('fora do expediente');
        $this->agendar(data: self::DOMINGO);
    }

    public function testNaoPermiteServicoTerminarAposFechamento(): void
    {
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('fora do expediente');
        $this->agendar(servico: self::COLORACAO, prof: self::ANA, hora: '17:00'); // terminaria 19:00
    }

    public function testNaoPermiteConflitoDeHorarioDoProfissional(): void
    {
        $this->agendar(hora: '09:00');
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('ocupado');
        $this->agendar(cliente: self::JOAO, hora: '09:00');
    }

    public function testPermiteMesmoHorarioComOutroProfissional(): void
    {
        $this->agendar(hora: '09:00');
        $id = $this->agendar(cliente: self::JOAO, prof: self::ANA, hora: '09:00');
        $this->assertGreaterThan(0, $id);
    }

    public function testNaoPermiteClienteEmDoisLugaresAoMesmoTempo(): void
    {
        $this->agendar(hora: '09:00');
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('Você já possui outro agendamento');
        $this->agendar(prof: self::ANA, hora: '09:00');
    }

    public function testProfissionalPrecisaRealizarOServico(): void
    {
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('não realiza');
        $this->agendar(servico: self::COLORACAO, prof: self::CARLOS);
    }

    public function testNaoPermiteServicoOuProfissionalInativo(): void
    {
        try {
            $this->agendar(servico: 3);
            $this->fail('Deveria recusar serviço inativo');
        } catch (RegraNegocioException $e) {
            $this->assertStringContainsString('Serviço inválido', $e->getMessage());
        }
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('Profissional inválido');
        $this->agendar(prof: 3);
    }

    public function testHorarioCanceladoVoltaASerDisponivel(): void
    {
        $id = $this->agendar(hora: '09:00');
        $this->service->cancelarPeloCliente($id, self::MARIA, $this->agora);
        $novo = $this->agendar(cliente: self::JOAO, hora: '09:00');
        $this->assertGreaterThan($id, $novo);
    }

    public function testHorariosDisponiveisExcluemOcupados(): void
    {
        $antes = $this->service->horariosDisponiveis(self::CARLOS, self::CORTE, self::SEGUNDA, $this->agora);
        $this->assertCount(20, $antes); // 08:00 a 17:30, de 30 em 30 min
        $this->assertSame('08:00', $antes[0]);
        $this->assertSame('17:30', end($antes));

        $this->agendar(hora: '10:00');
        $depois = $this->service->horariosDisponiveis(self::CARLOS, self::CORTE, self::SEGUNDA, $this->agora);
        $this->assertNotContains('10:00', $depois);
        $this->assertContains('10:30', $depois);
        $this->assertCount(19, $depois);
    }

    public function testHorariosDisponiveisRespeitamDuracaoDoServico(): void
    {
        $slots = $this->service->horariosDisponiveis(self::ANA, self::COLORACAO, self::SEGUNDA, $this->agora);
        $this->assertSame('16:00', end($slots)); // 16:00 + 2h = 18:00 (fechamento)
    }

    public function testHorariosDoDiaAtualIgnoramHorasPassadas(): void
    {
        $agora = new DateTimeImmutable(self::SEGUNDA . ' 13:10');
        $slots = $this->service->horariosDisponiveis(self::CARLOS, self::CORTE, self::SEGUNDA, $agora);
        $this->assertSame('13:30', $slots[0]);
    }

    public function testDomingoNaoTemHorarios(): void
    {
        $this->assertSame([], $this->service->horariosDisponiveis(self::CARLOS, self::CORTE, self::DOMINGO, $this->agora));
    }

    public function testClienteCancelaComAntecedencia(): void
    {
        $id = $this->agendar(hora: '15:00');
        $this->service->cancelarPeloCliente($id, self::MARIA, new DateTimeImmutable(self::SEGUNDA . ' 12:59'));
        $this->assertSame('cancelado', $this->agendamentos->buscar($id)['status']);
    }

    public function testClienteNaoCancelaComMenosDeDuasHoras(): void
    {
        $id = $this->agendar(hora: '15:00');
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('2 horas de antecedência');
        $this->service->cancelarPeloCliente($id, self::MARIA, new DateTimeImmutable(self::SEGUNDA . ' 13:30'));
    }

    public function testClienteNaoCancelaAgendamentoDeOutroCliente(): void
    {
        $id = $this->agendar();
        $this->expectException(RegraNegocioException::class);
        $this->expectExceptionMessage('não encontrado');
        $this->service->cancelarPeloCliente($id, self::JOAO, $this->agora);
    }

    public function testAdminConfirmaEConcluiAgendamento(): void
    {
        $id = $this->agendar();
        $this->service->alterarStatus($id, 'confirmado');
        $this->service->alterarStatus($id, 'concluido');
        $this->assertSame('concluido', $this->agendamentos->buscar($id)['status']);
    }

    public function testAgendamentoConcluidoNaoPodeSerCancelado(): void
    {
        $id = $this->agendar();
        $this->service->alterarStatus($id, 'concluido');
        $this->expectException(RegraNegocioException::class);
        $this->service->alterarStatus($id, 'cancelado');
    }

    public function testResumoEFaturamentoDoPeriodo(): void
    {
        $this->agendar(hora: '09:00');                                          // corte 45
        $this->agendar(cliente: self::JOAO, servico: self::COLORACAO, prof: self::ANA, hora: '10:00'); // 150
        $cancelado = $this->agendar(cliente: self::JOAO, hora: '15:00');
        $this->service->cancelarPeloCliente($cancelado, self::JOAO, $this->agora);

        $resumo = $this->agendamentos->resumoPorStatus('2030-01-01', '2030-01-31');
        $this->assertSame(2, $resumo['agendado']);
        $this->assertSame(1, $resumo['cancelado']);
        $this->assertEqualsWithDelta(195.0, $this->agendamentos->faturamentoPrevisto('2030-01-01', '2030-01-31'), 0.001);
    }
}
