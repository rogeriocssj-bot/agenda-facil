const { chromium } = require('playwright');
const fs = require('fs');
const B = 'http://127.0.0.1:8000/index.php';
const S = 'http://127.0.0.1:8001';
const SEG = process.argv[2], DOM = process.argv[3];
const marcas = [];
const A = 'http://127.0.0.1:8002/index.php';
let t0;
const sleep = (s) => new Promise(r => setTimeout(r, s * 1000));
(async () => {
  const browser = await chromium.launch({ args: ['--lang=pt-BR'] });
  const ctx = await browser.newContext({
    viewport: { width: 1280, height: 720 }, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo',
    recordVideo: { dir: '/tmp/claude-0/video/rec', size: { width: 1280, height: 720 } },
  });
  await ctx.addInitScript(() => {
    const css = `#__leg{position:fixed;left:50%;transform:translateX(-50%);bottom:18px;z-index:99999;background:rgba(17,24,39,.88);color:#fff;
      font:600 19px system-ui,sans-serif;padding:10px 22px;border-radius:12px;max-width:85%;text-align:center;pointer-events:none;box-shadow:0 6px 20px rgba(0,0,0,.3)}
      #__leg:empty{display:none}#__cur{position:fixed;z-index:100000;width:18px;height:18px;border-radius:50%;background:rgba(245,158,11,.85);
      border:2px solid #fff;box-shadow:0 0 0 2px rgba(0,0,0,.25);pointer-events:none;transform:translate(-50%,-50%);transition:width .1s,height .1s;left:-50px;top:-50px}
      #__cur.down{width:30px;height:30px;background:rgba(245,158,11,.5)}`;
    const mk = () => {
      if (window.top !== window) return;
      const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
      const l = document.createElement('div'); l.id = '__leg'; l.textContent = window.name || ''; document.body.appendChild(l); window.__cor = () => { const t = l.textContent; l.style.background = t.startsWith('ANTES') ? 'rgba(185,28,28,.94)' : t.startsWith('DEPOIS') ? 'rgba(21,128,61,.94)' : ''; }; window.__cor();
      const c = document.createElement('div'); c.id = '__cur'; document.body.appendChild(c);
      const p = JSON.parse(sessionStorage.getItem('__cur') || 'null'); if (p) { c.style.left = p[0] + 'px'; c.style.top = p[1] + 'px'; }
      document.addEventListener('mousemove', e => { c.style.left = e.clientX + 'px'; c.style.top = e.clientY + 'px'; try { sessionStorage.setItem('__cur', JSON.stringify([e.clientX, e.clientY])) } catch (_) {} }, true);
      document.addEventListener('mousedown', () => c.classList.add('down'), true);
      document.addEventListener('mouseup', () => c.classList.remove('down'), true);
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mk); else mk();
  });
  t0 = Date.now();
  const page = await ctx.newPage();
  page.on('dialog', d => setTimeout(() => d.accept(), 1200));
  let mx = 640, my = 360;
  const leg = async (t) => { await page.evaluate(t => { window.name = t; const l = document.getElementById('__leg'); if (l) { l.textContent = t; if (window.__cor) window.__cor(); } }, t).catch(() => {}); };
  const secao = async (titulo, legenda) => { marcas.push({ t: (Date.now() - t0) / 1000, titulo }); await leg(legenda !== undefined ? legenda : titulo); };
  const mover = async (loc) => {
    await loc.scrollIntoViewIfNeeded(); const b = await loc.boundingBox();
    const x = b.x + b.width / 2, y = b.y + b.height / 2;
    await page.mouse.move(x, y, { steps: 25 }); mx = x; my = y; await sleep(0.35);
  };
  const clicar = async (sel, nav = false) => {
    const loc = typeof sel === 'string' ? page.locator(sel).first() : sel;
    await mover(loc);
    if (nav) await Promise.all([page.waitForNavigation(), page.mouse.click(mx, my)]); else await page.mouse.click(mx, my);
    await sleep(0.6);
  };
  const digitar = async (sel, txt) => { await clicar(sel); await page.keyboard.type(txt, { delay: 75 }); await sleep(0.3); };
  const escolher = async (sel, val) => { await mover(page.locator(sel)); await page.selectOption(sel, val); await page.dispatchEvent(sel, 'change'); await sleep(1); };
  const rolar = async (dy, passos = 20) => { for (let i = 0; i < passos; i++) { await page.mouse.wheel(0, dy / passos); await sleep(0.05); } await sleep(0.8); };
  const ir = async (url) => { await page.goto(url); await sleep(0.8); };


  const sair = async () => { if (await page.locator('button:has-text("Sair")').count()) await clicar('button:has-text("Sair")', true); };
  const cadastroDemo = async (base, email, legVazio) => {
    await ir(base + '?r=cadastro'); await sleep(1.5);
    await clicar('main button[type=submit]'); await leg(legVazio);
    await mover(page.locator('#senha')); await sleep(6);
    await digitar('#nome', 'Bruno Teste'); await digitar('#email', email);
    await digitar('#senha', 'bruno123'); await digitar('#senha_confirmacao', 'bruno123'); await sleep(1);
    const btn = page.locator('main button[type=submit]'); await mover(btn);
    const nav = page.waitForNavigation({ timeout: 4000 }).then(() => true).catch(() => false);
    await page.mouse.click(mx, my); return nav;
  };
  const servicoDemo = async (base) => {
    await ir(base + '?r=servicos/form'); await sleep(1);
    await digitar('#nome', 'Barba'); await digitar('#preco', 'abc');
    await clicar('main button[type=submit]', true); await sleep(5);
    await page.fill('#nome', ''); await digitar('#nome', 'Sobrancelha'); await page.fill('#preco', ''); await digitar('#preco', '25,00'); await sleep(0.8);
    await mover(page.locator('main button[type=submit]'));
    const nav = page.waitForNavigation({ timeout: 4000 }).then(() => true).catch(() => false);
    await page.mouse.click(mx, my); return nav;
  };
  const loginCliente = async () => {
    await digitar('#email', 'cliente@agendafacil.com'); await digitar('#senha', 'cliente123');
    await clicar('main button[type=submit]', true);
  };

  // 0. Abertura
  await ir(S + '/titulo2.html');
  await secao('Abertura', 'Vídeo 2 — Correções realizadas após os testes'); await sleep(13);
  // 1. Resumo do laudo
  await ir(S + '/laudo.html');
  await secao('Resumo do laudo', 'Resumo do laudo de qualidade: 5 defeitos, todos corrigidos'); await sleep(22);

  // 2. BUG-01 e BUG-02
  await secao('BUG-01 e BUG-02 — antes', 'ANTES — Cadastro com a versão antiga');
  let ok = await cadastroDemo(A, 'bruno.antes@exemplo.com', 'ANTES — "Senha é obrigatório": erro de concordância (BUG-02)');
  await leg('ANTES — Clicou em "Criar conta" e nada aconteceu (BUG-01)'); await sleep(7);
  console.log('antes cadastro navegou?', ok);
  await secao('BUG-01 e BUG-02 — depois', 'DEPOIS — Mesmo passo a passo com a versão corrigida');
  ok = await cadastroDemo(B, 'bruno.depois@exemplo.com', 'DEPOIS — "O campo Senha é obrigatório": frase corrigida');
  await sleep(1.5); console.log('depois cadastro navegou?', ok);
  await leg('DEPOIS — A conta é criada no primeiro clique'); await sleep(6);
  await sair();

  // 3. BUG-03
  await secao('BUG-03 — antes', 'ANTES — Erros do servidor no cadastro de serviço');
  await ir(A + '?r=login'); await digitar('#email', 'admin@agendafacil.com'); await digitar('#senha', 'admin123'); await clicar('main button[type=submit]', true);
  ok = await servicoDemo(A); console.log('antes servico navegou?', ok);
  await leg('ANTES — Campos com erro sem destaque e o clique em Salvar se perdeu'); await sleep(7);
  await secao('BUG-03 — depois', 'DEPOIS — Campos com erro destacados em vermelho');
  ok = await servicoDemo(B); console.log('depois servico navegou?', ok);
  await sleep(1.5); await leg('DEPOIS — Corrigido o dado, o serviço é salvo no primeiro clique'); await sleep(6);
  await sair();

  // 4. BUG-04 e BUG-05
  await secao('BUG-04 e BUG-05 — antes', 'ANTES — Cliente clica em "Agendar" sem estar logado');
  await ir(A); await rolar(380);
  await clicar(page.locator('.card').filter({ hasText: 'Coloração' }).locator('a'), true); await sleep(2);
  await loginCliente();
  await leg('ANTES — Depois do login, o cliente cai em outra tela e perde o serviço (BUG-04)'); await sleep(7);
  await leg('ANTES — Abrindo a Coloração de novo pelo cartão do serviço');
  await ir(A); await rolar(380);
  await clicar(page.locator('.card').filter({ hasText: 'Coloração' }).locator('a'), true); await sleep(2);
  await clicar('#data'); await page.fill('#data', SEG); await page.dispatchEvent('#data', 'change'); await sleep(1.5);
  await mover(page.locator('#profissional_id'));
  await leg('ANTES — Profissional não vem selecionado e os horários não aparecem (BUG-05)'); await sleep(7);
  await sair();
  await secao('BUG-04 e BUG-05 — depois', 'DEPOIS — Mesmo caminho com a versão corrigida');
  await ir(B); await rolar(380);
  await clicar(page.locator('.card').filter({ hasText: 'Coloração' }).locator('a'), true); await sleep(2);
  await loginCliente();
  await leg('DEPOIS — Volta para o agendamento com o serviço e a profissional já escolhidos'); await sleep(6);
  await clicar('#data'); await page.fill('#data', SEG); await page.dispatchEvent('#data', 'change'); await page.waitForSelector('.slot');
  await mover(page.locator('.slot').first());
  await leg('DEPOIS — Os horários livres aparecem normalmente'); await sleep(6);

  // 5. Testes de regressão
  await secao('Testes de regressão', 'Testes de regressão: PHPUnit depois das correções');
  await ir(S + '/terminal.html'); await sleep(30);
  await leg('58 testes, 107 verificações, nenhuma falha'); await sleep(5);

  // 6. Encerramento
  await ir(S + '/fim2.html');
  await secao('Encerramento', ''); await sleep(10);

  marcas.push({ t: (Date.now() - t0) / 1000, titulo: 'FIM' });
  const vpath = await page.video().path();
  await ctx.close(); await browser.close();
  fs.writeFileSync('/tmp/claude-0/video/marcas2.json', JSON.stringify({ video: vpath, marcas }, null, 1));
  console.log(vpath, marcas);
})().catch(e => { console.error('FALHOU', e); process.exit(1); });
