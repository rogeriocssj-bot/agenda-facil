<?php
declare(strict_types=1);

/**
 * Bootstrap dos testes.
 * Os testes de integração usam SQLite em memória, então NÃO precisam de MySQL instalado.
 */
$raiz = dirname(__DIR__);

if (is_file($raiz . '/vendor/autoload.php')) {
    require $raiz . '/vendor/autoload.php';
}
spl_autoload_register(function (string $classe) use ($raiz): void {
    $mapa = ['App\\' => '/app/', 'Tests\\' => '/tests/'];
    foreach ($mapa as $prefixo => $pasta) {
        if (str_starts_with($classe, $prefixo)) {
            $arquivo = $raiz . $pasta . str_replace('\\', '/', substr($classe, strlen($prefixo))) . '.php';
            if (is_file($arquivo)) {
                require $arquivo;
            }
        }
    }
});
require_once $raiz . '/app/Core/helpers.php';

date_default_timezone_set('America/Sao_Paulo');
$_SESSION = [];
