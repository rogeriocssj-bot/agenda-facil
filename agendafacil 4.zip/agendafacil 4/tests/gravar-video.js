const { chromium } = require('playwright');
const fs = require('fs');
const B = 'http://127.0.0.1:8000/index.php';
const S = 'http://127.0.0.1:8001';
const SEG = process.argv[2], DOM = process.argv[3];
const marcas = [];
let t0;
const sleep = (s) => new Promise(r => setTimeout(r, s * 1000));
(async () => {
  const browser = await chromium.launch({ args: ['--lang=pt-BR'] });
  const ctx = await browser.newContext({
    viewport: { width: 1280, height: 720 }, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo',
    recordVideo: { dir: '/tmp/claude-0/video/rec', size: { width: 1280, height: 720 } },
  });
  await ctx.addInitScript(() => {
    const css = `#__leg{position:fixed;left:50%;transform:translateX(-50%);bottom:18px;z-index:99999;background:rgba(17,24,39,.88);color:#fff;
      font:600 19px system-ui,sans-serif;padding:10px 22px;border-radius:12px;max-width:85%;text-align:center;pointer-events:none;box-shadow:0 6px 20px rgba(0,0,0,.3)}
      #__leg:empty{display:none}#__cur{position:fixed;z-index:100000;width:18px;height:18px;border-radius:50%;background:rgba(245,158,11,.85);
      border:2px solid #fff;box-shadow:0 0 0 2px rgba(0,0,0,.25);pointer-events:none;transform:translate(-50%,-50%);transition:width .1s,height .1s;left:-50px;top:-50px}
      #__cur.down{width:30px;height:30px;background:rgba(245,158,11,.5)}`;
    const mk = () => {
      if (window.top !== window) return;
      const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
      const l = document.createElement('div'); l.id = '__leg'; l.textContent = window.name || ''; document.body.appendChild(l);
      const c = document.createElement('div'); c.id = '__cur'; document.body.appendChild(c);
      const p = JSON.parse(sessionStorage.getItem('__cur') || 'null'); if (p) { c.style.left = p[0] + 'px'; c.style.top = p[1] + 'px'; }
      document.addEventListener('mousemove', e => { c.style.left = e.clientX + 'px'; c.style.top = e.clientY + 'px'; try { sessionStorage.setItem('__cur', JSON.stringify([e.clientX, e.clientY])) } catch (_) {} }, true);
      document.addEventListener('mousedown', () => c.classList.add('down'), true);
      document.addEventListener('mouseup', () => c.classList.remove('down'), true);
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mk); else mk();
  });
  t0 = Date.now();
  const page = await ctx.newPage();
  page.on('dialog', d => setTimeout(() => d.accept(), 1200));
  let mx = 640, my = 360;
  const leg = async (t) => { await page.evaluate(t => { window.name = t; const l = document.getElementById('__leg'); if (l) l.textContent = t; }, t).catch(() => {}); };
  const secao = async (titulo, legenda) => { marcas.push({ t: (Date.now() - t0) / 1000, titulo }); await leg(legenda || titulo); };
  const mover = async (loc) => {
    await loc.scrollIntoViewIfNeeded(); const b = await loc.boundingBox();
    const x = b.x + b.width / 2, y = b.y + b.height / 2;
    await page.mouse.move(x, y, { steps: 25 }); mx = x; my = y; await sleep(0.35);
  };
  const clicar = async (sel, nav = false) => {
    const loc = typeof sel === 'string' ? page.locator(sel).first() : sel;
    await mover(loc);
    if (nav) await Promise.all([page.waitForNavigation(), page.mouse.click(mx, my)]); else await page.mouse.click(mx, my);
    await sleep(0.6);
  };
  const digitar = async (sel, txt) => { await clicar(sel); await page.keyboard.type(txt, { delay: 75 }); await sleep(0.3); };
  const escolher = async (sel, val) => { await mover(page.locator(sel)); await page.selectOption(sel, val); await page.dispatchEvent(sel, 'change'); await sleep(1); };
  const rolar = async (dy, passos = 20) => { for (let i = 0; i < passos; i++) { await page.mouse.wheel(0, dy / passos); await sleep(0.05); } await sleep(0.8); };
  const ir = async (url) => { await page.goto(url); await sleep(0.8); };

  // 1. Abertura
  await ir(B);
  await secao('Abertura', 'AgendaFácil — Sistema web de agendamento de serviços');
  await sleep(12);
  await leg('PHP 8 · Padrão MVC · MySQL · HTML, CSS e JavaScript');
  await sleep(10);
  // 2. Problema
  await secao('O problema e a página inicial', 'Problema: agendamento por WhatsApp gera horários duplicados');
  await mover(page.locator('.hero h1')); await sleep(6);
  await rolar(420); await leg('Catálogo de serviços com duração e preço');
  for (const n of [0, 1, 2]) { await mover(page.locator('.card').nth(n)); await sleep(2.5); }
  await sleep(4); await rolar(-420); await sleep(2);

  // 3. Cadastro
  await secao('Criar conta e validações', 'Criar conta: validação dos campos em tempo real');
  await clicar('a:has-text("Criar conta")', true); await sleep(3);
  await clicar('main button[type=submit]'); await leg('Enviando vazio: cada campo mostra o que falta'); await sleep(7);
  await digitar('#nome', 'Joana Martins');
  await digitar('#email', 'joana.martins@exemplo.com');
  await leg('Máscara automática no telefone');
  await digitar('#telefone', '11987654321'); await sleep(2.5);
  await leg('Senha com botão Mostrar/Ocultar');
  await digitar('#senha', 'joana123'); await clicar('.ver-senha'); await sleep(2.5); await clicar('.ver-senha');
  await digitar('#senha_confirmacao', 'joana123'); await sleep(1.5);
  await clicar('main button[type=submit]', true);
  await leg('Conta criada: o sistema já abre a tela de agendamento'); await sleep(6);

  // 4. Agendamento
  await secao('Agendamento em 4 passos', 'Passo 1: escolher o serviço');
  const opts = await page.$$eval('#servico_id option', os => os.map(o => [o.value, o.textContent.trim()]));
  const val = n => opts.find(o => o[1].startsWith(n))[0];
  await escolher('#servico_id', val('Coloração')); await sleep(3);
  await leg('Passo 2: só aparecem profissionais que fazem esse serviço');
  await mover(page.locator('#profissional_id')); await sleep(6);
  await leg('Passo 3: domingo não tem atendimento');
  await clicar('#data'); await page.fill('#data', DOM); await page.dispatchEvent('#data', 'change'); await sleep(1);
  await mover(page.locator('#horarios')); await sleep(6);
  await page.fill('#data', SEG); await page.dispatchEvent('#data', 'change'); await page.waitForSelector('.slot');
  await leg('Passo 4: só horários livres — o último é 16:00, porque a coloração dura 2 horas');
  await mover(page.locator('.slot').last()); await sleep(7);
  await leg('De 11:30 a 14:30 não aparece nada: a profissional tem cliente das 13:00 às 15:00');
  await mover(page.locator('.slot >> text=11:00')); await sleep(7);
  await clicar(page.locator('.slot >> text=10:00'));
  await leg('Observação opcional e confirmação');
  await digitar('#observacao', 'Prefiro tons de castanho');
  await clicar('#btn-confirmar', true);
  await leg('Agendamento confirmado com resumo'); await sleep(7);

  // 5. Sem conflito
  await secao('Horário reservado sai da lista', 'Verificando: o horário reservado some da lista');
  await ir(B + '?r=agendamentos/novo&servico=' + val('Coloração'));
  await page.waitForFunction(() => !document.getElementById('profissional_id').disabled);
  await page.fill('#data', SEG); await page.dispatchEvent('#data', 'change'); await page.waitForSelector('.slot');
  await mover(page.locator('.slot >> text=08:00')); await sleep(3);
  await mover(page.locator('.slot >> text=15:00')); await leg('O período das 10:00 às 12:00 sumiu: não há como marcar horário duplicado'); await sleep(8);

  // 6. Meus agendamentos
  await secao('Meus agendamentos', 'Meus agendamentos: status e cancelamento');
  await clicar('#menu a:text-is("Meus agendamentos")', true); await sleep(3);
  await mover(page.locator('.selo').first()); await sleep(4);
  await mover(page.locator('button:has-text("Cancelar")').first());
  await leg('Cancelamento permitido até 2 horas antes do horário'); await sleep(8);

  // 7. Admin
  await secao('Área do administrador', 'Área do administrador');
  await clicar('button:has-text("Sair")', true); await sleep(2);
  await leg('Login com senha errada');
  await digitar('#email', 'admin@agendafacil.com'); await digitar('#senha', 'errada');
  await clicar('main button[type=submit]', true); await sleep(5);
  await digitar('#senha', 'admin123'); await clicar('main button[type=submit]', true);
  await leg('Painel: indicadores do mês e atendimentos de hoje'); await sleep(4);
  for (const n of [0, 1, 3, 4]) { await mover(page.locator('.indicador').nth(n)); await sleep(2.2); }
  await rolar(300); await sleep(4);
  await secao('Agenda e status', 'Agenda geral com filtros');
  await clicar('#menu a:text-is("Agenda")', true); await sleep(3);
  await escolher('#f-status', 'agendado'); await clicar('button:has-text("Filtrar")', true); await sleep(4);
  await clicar('a:has-text("Limpar")', true); await sleep(2);
  await leg('Confirmar um atendimento');
  await clicar(page.locator('tbody tr').filter({ hasText: 'Luana' }).first().locator('button:has-text("Confirmar")'), true); await sleep(4);
  await leg('Concluir o atendimento');
  await clicar(page.locator('tbody tr').filter({ hasText: 'Maria Cliente' }).first().locator('button:has-text("Concluir")'), true); await sleep(3);
  await mover(page.locator('tbody tr').filter({ hasText: 'Maria Cliente' }).first().locator('.selo'));
  await leg('Concluído não oferece mais ações: regra de transição de status'); await sleep(7);

  // 8. Serviços e profissionais
  await secao('Serviços e profissionais', 'Cadastro de serviços com validação no servidor');
  await clicar('#menu a:text-is("Serviços")', true); await sleep(3);
  await clicar('a:has-text("Novo serviço")', true);
  await digitar('#nome', 'Barba'); await page.fill('#duracao_min', ''); await digitar('#duracao_min', '30'); await digitar('#preco', 'abc');
  await clicar('main button[type=submit]', true);
  await leg('Nome repetido e preço inválido são recusados'); await sleep(7);
  await page.fill('#nome', ''); await digitar('#nome', 'Hidratação capilar'); await page.fill('#preco', ''); await digitar('#preco', '60,00');
  await clicar('main button[type=submit]', true);
  await leg('Serviço cadastrado'); await sleep(5);
  await clicar('#menu a:text-is("Profissionais")', true);
  await leg('Cada profissional tem os serviços que realiza (relação N:N)'); await sleep(8);

  // 9. Celular
  await secao('Versão celular', 'Layout responsivo no celular');
  await ir(S + '/celular.html'); await sleep(4);
  const f = page.frameLocator('#f');
  await mover(f.locator('.hero h1')); await sleep(3);
  await page.mouse.wheel(0, 0);
  for (let i = 0; i < 14; i++) { await f.locator('body').evaluate((b, i) => window.scrollTo(0, i * 70), i); await sleep(0.12); }
  await sleep(3);
  for (let i = 14; i >= 0; i--) { await f.locator('body').evaluate((b, i) => window.scrollTo(0, i * 70), i); await sleep(0.06); }
  await leg('Menu recolhível');
  await mover(f.locator('.menu-toggle')); await page.mouse.click(mx, my); await sleep(6);

  // 10. Código
  await secao('Código MVC', 'Estrutura MVC: Models, Views, Controllers e Services');
  await ir(S + '/codigo.html'); await sleep(8);
  await leg('Regras de negócio isoladas em AgendamentoService');
  const m = page.locator('#m'); await mover(m);
  for (let i = 0; i < 12; i++) { await page.mouse.wheel(0, 90); await sleep(1.1); }
  await sleep(4);

  // 11. Testes
  await secao('Testes automatizados', 'Testes automatizados com PHPUnit');
  await ir(S + '/terminal.html'); await sleep(32);
  await leg('58 testes, 107 verificações, nenhuma falha'); await sleep(8);

  // 12. Encerramento
  await secao('Encerramento', 'AgendaFácil — obrigado!');
  await ir(B); await sleep(10);

  marcas.push({ t: (Date.now() - t0) / 1000, titulo: 'FIM' });
  const vpath = await page.video().path();
  await ctx.close(); await browser.close();
  fs.writeFileSync('/tmp/claude-0/video/marcas.json', JSON.stringify({ video: vpath, marcas }, null, 1));
  console.log(vpath, marcas);
})().catch(e => { console.error('FALHOU', e); process.exit(1); });
