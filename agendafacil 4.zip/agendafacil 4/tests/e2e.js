const { chromium } = require('playwright');
const B = 'http://127.0.0.1:8000/index.php';
const OUT = process.argv[2];
const log = (...a) => console.log(...a);
function proxSegunda() { const d = new Date(); d.setDate(d.getDate() + ((8 - d.getDay()) % 7 || 7)); return d.toISOString().slice(0,10); }
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 } });
  const page = await ctx.newPage();
  const errosJS = [];
  page.on('pageerror', e => errosJS.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errosJS.push(m.text()); });
  page.on('dialog', d => d.accept());
  const enviar = async (sel) => Promise.all([page.waitForNavigation(), page.click(sel)]);
  const shot = async (n) => page.screenshot({ path: `${OUT}/${n}.png`, fullPage: true });

  await page.goto(B); await shot('01-home');
  await page.goto(B + '?r=cadastro'); await page.click('main button[type=submit]'); await shot('02-cadastro-validacao');
  log('erros cadastro vazio:', await page.locator('.erro-campo').count());
  const email = 'teste' + Date.now() + '@exemplo.com';
  await page.fill('#nome', 'Joana Teste'); await page.fill('#email', email);
  await page.type('#telefone', '11977776666'); log('mascara:', await page.inputValue('#telefone'));
  await page.fill('#senha', 'senha123'); await page.fill('#senha_confirmacao', 'senha123');
  await enviar('main button[type=submit]');
  log('apos cadastro url:', page.url(), '|', await page.locator('.alerta').innerText().catch(()=>'-'));

  const seg = proxSegunda(); log('data:', seg);
  const opts = await page.$$eval('#servico_id option', os => os.map(o => [o.value, o.textContent.trim()]));
  const corte = opts.find(o => o[1].startsWith('Corte'))[0];
  await page.selectOption('#servico_id', corte);
  await page.waitForFunction(() => !document.getElementById('profissional_id').disabled);
  const profs = await page.$$eval('#profissional_id option', os => os.map(o => o.textContent.trim())); log('profs:', profs);
  await page.selectOption('#profissional_id', { index: 1 });
  await page.fill('#data', seg); await page.dispatchEvent('#data', 'change');
  await page.waitForSelector('.slot');
  log('slots:', await page.locator('.slot').count());
  await page.click('.slot >> text=10:00'); await page.fill('#observacao', 'Teste automatizado');
  await shot('03-novo-agendamento');
  await enviar('#btn-confirmar');
  log('apos agendar:', page.url(), '|', await page.locator('.alerta').innerText().catch(()=>'-'));
  await shot('04-meus-agendamentos');

  // tenta de novo o mesmo horário -> não deve aparecer
  await page.goto(B + '?r=agendamentos/novo&servico=' + corte);
  await page.waitForFunction(() => !document.getElementById('profissional_id').disabled);
  await page.selectOption('#profissional_id', { index: 1 });
  await page.fill('#data', seg); await page.dispatchEvent('#data', 'change'); await page.waitForSelector('.slot');
  log('10:00 ainda listado?', await page.locator('.slot >> text=10:00').count());
  // domingo
  const dom = new Date(seg); dom.setDate(dom.getDate() - 1);
  await page.fill('#data', dom.toISOString().slice(0,10)); await page.dispatchEvent('#data', 'change');
  log('domingo msg:', await page.locator('#horarios').innerText());
  // envio sem horário
  await page.fill('#data', seg); await page.dispatchEvent('#data', 'change'); await page.waitForSelector('.slot');
  await page.click('#btn-confirmar'); log('sem horario msg:', await page.locator('.erro-campo').allInnerTexts());
  await shot('05-validacao-horario');

  // cancelar
  await page.goto(B + '?r=agendamentos');
  await enviar('text=Cancelar');
  log('cancelar:', await page.locator('.alerta').innerText().catch(()=>'-'));
  // cliente acessando admin
  await page.goto(B + '?r=admin'); log('cliente->admin:', await page.locator('h1').innerText());
  await enviar('text=Sair');

  // admin
  await page.goto(B + '?r=login'); await page.fill('#email', 'admin@agendafacil.com'); await page.fill('#senha', 'errada');
  await enviar('main button[type=submit]'); log('login errado:', await page.locator('.alerta').innerText());
  await shot('06-login-erro');
  await page.fill('#senha', 'admin123'); await enviar('main button[type=submit]');
  log('admin url:', page.url()); await shot('07-painel-admin');
  await page.goto(B + '?r=admin/agenda'); await shot('08-agenda-geral');
  log('linhas agenda:', await page.locator('tbody tr').count());
  await page.goto(B + '?r=servicos/form'); await page.fill('#nome', 'Corte de cabelo'); await page.fill('#duracao_min', '5'); await page.fill('#preco', 'abc');
  await page.click('main button[type=submit]'); log('servico erros (navegador):', await page.locator('.erro-campo').allInnerTexts());
  await page.fill('#duracao_min', '30'); await enviar('main button[type=submit]');
  log('servico erros:', await page.locator('.erro-campo').allInnerTexts()); await shot('09-servico-validacao');
  await page.fill('#nome', 'Hidratação'); await page.fill('#duracao_min', '45'); await page.fill('#preco', '60,00');
  await enviar('main button[type=submit]');
  log('servico salvo:', await page.locator('.alerta').innerText().catch(()=>'-')); await shot('10-servicos');
  await page.goto(B + '?r=profissionais/form'); await page.fill('#nome', 'Bruno'); await enviar('main button[type=submit]');
  log('prof erros:', await page.locator('.erro-campo').allInnerTexts());
  await page.goto(B + '?r=profissionais'); await shot('11-profissionais');
  await page.goto(B + '?r=naoexiste'); log('404:', await page.locator('h1').innerText());

  // mobile
  const m = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true });
  const mp = await m.newPage(); await mp.goto(B); await mp.screenshot({ path: `${OUT}/12-mobile-home.png`, fullPage: true });
  await mp.click('.menu-toggle'); await mp.screenshot({ path: `${OUT}/13-mobile-menu.png` });
  const sw = await mp.evaluate(() => document.documentElement.scrollWidth); log('mobile scrollWidth:', sw);
  log('erros JS:', errosJS);
  await browser.close();
})().catch(e => { console.error('FALHOU', e); process.exit(1); });
